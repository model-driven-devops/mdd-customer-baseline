from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ansible.errors import AnsibleFilterError
from ansible.module_utils.common.text.converters import to_native, to_text
from ansible.parsing.yaml.dumper import AnsibleDumper
import yaml


class MyDumper(AnsibleDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super(MyDumper, self).increase_indent(flow, False)


def to_even_nicer_yaml(a, indent=2, *args, **kw):
    '''Make verbose, human-readable yaml'''
    try:
        transformed = yaml.dump(a, Dumper=MyDumper, indent=indent, allow_unicode=True, default_flow_style=False, sort_keys=False, **kw)
    except Exception as e:
        raise AnsibleFilterError("to_nice_yaml - %s" % to_native(e), orig_exc=e)
    return to_text(transformed)


class FilterModule(object):
    def filters(self):
        return {
            'to_even_nicer_yaml': to_even_nicer_yaml
        }
